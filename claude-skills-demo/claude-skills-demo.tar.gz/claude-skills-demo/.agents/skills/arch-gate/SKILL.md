---
name: arch-gate
description: Invoked automatically by .github/workflows/arch-gate.yml on every PR — not for interactive developer use. Use /sync-arch during a session instead. Outputs JSON and exits 2 on layer violations, for use in CI pipelines.
---

# arch-gate — CI architecture enforcement

## Invocation

```bash
# In GitHub Actions or local pre-merge check:
claude --print --output-format json \
  "/arch-gate\nCheck all files changed in this PR for layer violations." \
  | tee arch-report.json

violations=$(jq '.violations | length' arch-report.json)
[ "$violations" -eq 0 ] || exit 2
```

## Difference from /sync-arch

`/sync-arch` is interactive — it explains findings conversationally and
waits for the developer. `/arch-gate` is non-interactive — it outputs
only structured JSON, no prose, and exits with a machine-readable code.

## Input

Files to check: all files modified in the current git diff against main.

```bash
git diff --name-only origin/main...HEAD | grep -E '\.(c|h|cpp)$'
```

## Rules to enforce

Identical to ARCHITECTURE.md. Checked in this priority order:

1. **Transport boundary** — any `coll/` file calling MPI, OFI, libfabric,
   or any network API directly (not through `comm->atl`)
2. **Memory discipline** — `malloc`/`free`/`new` in `coll/` (use `ccl_buffer_t`)
3. **Reduction dispatch** — hardcoded arithmetic instead of `ccl_reduction_fn_t`
4. **In-place safety** — no `sendbuf == recvbuf` guard before first read/write
5. **Edge cases** — no guard for `count == 0` or `comm->size == 1` before
   any division or index involving those values

## Output format — strict JSON, no prose

```json
{
  "schema": "arch-gate/v1",
  "checked_files": ["src/ring_allreduce.c", "include/ring_allreduce.h"],
  "violations": [
    {
      "rule": 1,
      "severity": "VIOLATION",
      "file": "src/ring_allreduce.c",
      "line": 18,
      "found": "MPI_Send call inside coll/ layer function send_chunk()",
      "required": "All sends must go through comm->atl (atl_req_t interface)",
      "fix": "Replace MPI_Send with atl_ep_send() via comm->atl handle"
    }
  ],
  "passes": [
    { "rule": 2, "description": "No direct malloc/free found in coll/ files" }
  ],
  "summary": {
    "violation_count": 1,
    "pass_count": 1,
    "exit_code": 2
  }
}
```

## Exit codes

| Code | Meaning |
|------|---------|
| 0 | All checks passed — safe to merge |
| 2 | One or more VIOLATIONS found — block merge |

Do not exit 1. Exit 0 or 2 only. This makes it easy to distinguish
"arch violation" from generic script failure in CI logs.

## What NOT to output

- No prose explanation
- No markdown formatting
- No preamble or postamble
- Only the JSON object above

The CI pipeline reads stdout as JSON. Any non-JSON output breaks the pipeline.
