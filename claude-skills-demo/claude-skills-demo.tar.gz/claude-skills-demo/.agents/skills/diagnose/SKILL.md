---
name: diagnose
description: Use when debugging a crash, hang, or incorrect result in oneCCL or MPI code. Requires a minimal reproducer before any code edits.
---

# diagnose — reproducer-first debugging

## The rule

**You may not edit any source file until a minimal reproducer exists
that reliably triggers the bug in isolation.**

## Step 1 — understand the failure

Read the error log, crash output, or test failure provided.
Identify: crash / hang / wrong result / compile error.

## Step 2 — write a minimal reproducer

Write the smallest possible C program (target: under 40 lines) that:
- Uses only the failing function and its direct dependencies
- Triggers the failure deterministically
- Prints a clear PASS / FAIL verdict

Save it to `scripts/repro_<bug_name>.c`.

For oneCCL/MPI bugs, the reproducer must include:
- A `ccl_comm_t` stub with the exact `rank` and `size` values that trigger the bug
- The minimal call path — no unrelated collectives or setup

## Step 3 — confirm the reproducer fails

Run the reproducer. If it does not fail, the hypothesis is wrong.
Revise and rerun. Do not proceed to Step 4 until it reliably fails.

## Step 4 — identify root cause

With the reproducer in hand, identify the exact line and condition
that causes the failure. State it explicitly:

```
Root cause: <file>:<line> — <condition> causes <effect>
```

## Step 5 — propose a targeted patch

Now (and only now) propose a minimal patch.
The patch must not touch any code path not exercised by the reproducer.

## Bonus: the reproducer becomes a regression test

After the fix, the reproducer should pass. Add it to `scripts/` and
note it in the PR as a regression test.
