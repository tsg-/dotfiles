---
name: handoff
description: Use when the current session is getting long, when branching to a prototype, or when switching tasks. Compresses session state to a clean Markdown file for a fresh agent session.
---

# handoff — session state compression

## When to invoke

- Context window is above 60% full
- You are about to explore a risky or experimental approach
- You need to hand off to a different model or tool
- End of a work block — preserve state before closing

## What to produce

Write a single Markdown file to `/tmp/handoff_<topic>_<YYYYMMDD>.md`.

**Never save to the project directory.** Handoff files are ephemeral
working notes, not project artifacts.

## File structure

```markdown
# Handoff: <task description>
Generated: <timestamp>
Session length estimate: <short / medium / long>

## What we are trying to do
<1-2 sentences. The goal, not the journey.>

## Current state
<What is working. What is not. Be concrete.>

## Key decisions made
<Bullet list. Each decision + the reason.>

## Files in scope
<List file paths and what role each plays.
 Do NOT paste file contents — use paths only.>

## The next action
<Exactly what the fresh session should do first.
 One concrete instruction.>

## Open questions
<What is still unknown or unresolved.>

## Dead ends (do not retry)
<Approaches that failed and why. Saves the fresh session
 from repeating mistakes.>
```

## Privacy rules

Before writing the file, scan for and REDACT:
- API keys, tokens, passwords (replace with `[REDACTED]`)
- Internal hostnames or IP addresses (replace with `[HOST]`)
- Personal names in code comments (replace with `[AUTHOR]`)

## Bidirectional use

This same format works in reverse: a prototype session can hand
learnings back to the main session. Mark the file:
`# Handoff: prototype → main — <what was learned>`
