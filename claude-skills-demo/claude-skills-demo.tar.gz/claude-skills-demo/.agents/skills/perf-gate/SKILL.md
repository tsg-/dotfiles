---
name: perf-gate
description: Use before merging any collective, transport, or kernel change. Runs OSU micro-benchmarks before and after, diffs results against perf-thresholds.json, and exits non-zero on regression. Also usable interactively to check a local build.
---

# perf-gate — performance regression enforcement

## When to invoke

- After implementing any change to `src/` (collectives) or `atl/` (transport)
- Before raising a PR that touches critical paths
- Automatically by CI on every merge to `main` (see `.github/workflows/perf-gate.yml`)

## What counts as a regression

Thresholds live in `perf-thresholds.json` in the project root.
They are the contract. Do not relax them without a separate PR and explicit sign-off.

```json
{
  "osu_latency_p50_us":   { "max": 2.1,  "ranks": 2  },
  "osu_latency_p99_us":   { "max": 4.8,  "ranks": 2  },
  "osu_bw_gbs":           { "min": 23.5, "ranks": 2  },
  "osu_allreduce_8_ms":   { "max": 0.42, "ranks": 8  },
  "osu_allreduce_64_ms":  { "max": 1.80, "ranks": 64 }
}
```

A result is a REGRESSION if it crosses the threshold by more than 3%.
The 3% margin absorbs natural run-to-run variance on shared hardware.
Results within 3% of threshold are flagged as WARNING, not REGRESSION.

## Step 1 — run benchmarks

Run the benchmark harness and save results:

```bash
bash scripts/run_osu.sh > /tmp/perf_results.json
```

If `scripts/run_osu.sh` does not exist, generate it using the template
at the bottom of this skill, adapted to the local MPI installation.

## Step 2 — compare against thresholds

Read `perf-thresholds.json` and compare every metric in `/tmp/perf_results.json`.

## Step 3 — output format

```
[REGRESSION] osu_allreduce_8_ms: measured 0.51ms vs threshold 0.42ms (+21%)
[WARNING]    osu_latency_p99_us: measured 4.71us vs threshold 4.8us (within 3%)
[PASS]       osu_latency_p50_us: measured 1.93us vs threshold 2.1us
[PASS]       osu_bw_gbs: measured 24.1 GB/s vs threshold 23.5 GB/s
```

If any REGRESSION is found:
1. List all regressions with measured vs threshold and % delta
2. Suggest which code path is most likely responsible based on what changed
3. Exit with code 1 (non-zero blocks CI merge)

If only WARNINGs: exit 0 but include warnings in output.
If all PASS: exit 0, print summary line only.

## run_osu.sh template

```bash
#!/bin/bash
# scripts/run_osu.sh — adapt paths to local MPI/OSU install
set -euo pipefail

OSU_DIR=${OSU_DIR:-/usr/local/libexec/osu-micro-benchmarks/mpi}
MPIRUN=${MPIRUN:-mpirun}
HOSTFILE=${HOSTFILE:-scripts/hostfile}
OUT={}

# 2-rank latency and bandwidth
LAT=$($MPIRUN -n 2 -hostfile $HOSTFILE $OSU_DIR/pt2pt/osu_latency | \
      awk '/^[0-9]/ {lat=$2} END {print lat}')
BW=$($MPIRUN  -n 2 -hostfile $HOSTFILE $OSU_DIR/pt2pt/osu_bw      | \
      awk '/^[0-9]/ {bw=$2}  END {print bw}')

# 8-rank and 64-rank allreduce (median of 3 runs)
AR8=$($MPIRUN  -n 8  -hostfile $HOSTFILE $OSU_DIR/collective/osu_allreduce | \
      awk '/^4096 / {print $2}')
AR64=$($MPIRUN -n 64 -hostfile $HOSTFILE $OSU_DIR/collective/osu_allreduce | \
      awk '/^4096 / {print $2}')

cat <<JSON
{
  "osu_latency_p50_us":  $LAT,
  "osu_bw_gbs":          $BW,
  "osu_allreduce_8_ms":  $(echo "$AR8  / 1000" | bc -l),
  "osu_allreduce_64_ms": $(echo "$AR64 / 1000" | bc -l)
}
JSON
```

## Notes

- Always run on the same hardware configuration (same node count, same NIC, same
  NUMA binding) as when thresholds were established. Results on different hardware
  are not comparable to the thresholds.
- If the cluster is unavailable, note "hardware unavailable — perf gate skipped"
  in the PR and assign a follow-up task. Do not silently pass.
- p99 latency data requires OSU >= 5.9 (`--percentile` flag). Check version first.
