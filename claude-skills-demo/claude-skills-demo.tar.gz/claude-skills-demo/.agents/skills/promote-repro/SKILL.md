---
name: promote-repro
description: Use after /diagnose writes a reproducer to scripts/repro_*.c. Promotes it to a registered CI test: adds a CMake test target, updates the test manifest, and drafts a PR comment explaining what regression it covers. Closes the loop between debugging and regression prevention.
---

# promote-repro — reproducer → regression test

## When to invoke

After `/diagnose` has written a reproducer that:
1. Reliably triggers the bug
2. Prints a clear PASS / FAIL verdict
3. Has been confirmed to fail on the buggy code

Invoke as: `/promote-repro scripts/repro_<name>.c`

## What this skill does

Takes a reproducer file and makes it a permanent part of the test suite,
so the bug can never silently reappear.

## Step 1 — validate the reproducer

Read the reproducer file. Confirm it:
- Has a `main()` that returns 0 on PASS and non-zero on FAIL
- Compiles with `gcc -I include <file> src/ring_allreduce.c`
- Is self-contained (no external test frameworks, no MPI cluster needed
  unless the bug is inherently multi-rank)

If any condition fails, stop and report what needs fixing before promotion.

## Step 2 — add to CMakeLists.txt

Find the test registration block in `CMakeLists.txt` (search for
`add_test` or `enable_testing`). Add:

```cmake
add_executable(repro_<name> scripts/repro_<name>.c src/ring_allreduce.c)
target_include_directories(repro_<name> PRIVATE include)
add_test(NAME regression_<name>
         COMMAND repro_<name>
         WORKING_DIRECTORY ${CMAKE_BINARY_DIR})
set_tests_properties(regression_<name> PROPERTIES
  LABELS "regression"
  TIMEOUT 30)
```

## Step 3 — update test manifest

If `scripts/TEST_MANIFEST.md` exists, append:

```markdown
| regression_<name> | <one-line description of the bug> | <date> | <PR or issue number> |
```

If the manifest doesn't exist, create it with a header row first.

## Step 4 — draft PR comment

Write the following to `/tmp/promote_repro_comment.md`:

```markdown
## Regression test added: `regression_<name>`

**Bug:** <one-sentence description from the reproducer comments>
**Root cause:** <from /diagnose output if available>
**Test file:** `scripts/repro_<name>.c`
**Triggers on:** <describe the conditions — e.g., "comm->size == 0">

This test will fail if the bug reappears. It runs as part of the
`regression` CTest label on every CI build.
```

Then say: "Draft PR comment written to /tmp/promote_repro_comment.md.
Copy it into your PR description or let me post it via `gh pr comment`."

## Step 5 — verify the promotion

Run:
```bash
cmake -B build && cmake --build build --target repro_<name>
ctest --build-dir build -L regression -V
```

Confirm the test:
- Fails on the current (buggy) code — or if the fix is already applied, PASS
- Is listed in `ctest -N` output

## What NOT to do

- Do not modify the reproducer logic — it must stay minimal
- Do not add test framework dependencies (no gtest, no criterion)
- Do not promote a reproducer that requires >8 MPI ranks — move it to the
  nightly multi-node suite instead and note this in the manifest
