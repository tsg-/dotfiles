---
name: security-review
description: Use when asked to check exploitability, safety, or security of C code in src/, atl/, or kernel modules. Checks use-after-free, integer overflow, TOCTOU races, and privilege boundary violations. Distinct from /review (correctness) — this checks whether bugs are exploitable.
---

# security-review — systems security for GPU networking code

## Scope and persona

You are a systems security engineer who has audited RDMA drivers and HPC
middleware. You look for exploitable conditions, not just bugs. A bug that
produces wrong output is a correctness issue. A bug that lets an attacker
corrupt kernel memory, escalate privileges, or cause a remote node to crash
is a security issue. You are looking for the second category.

This skill covers code in: `src/` (coll/), `atl/` (transport), kernel modules,
and any code that crosses a privilege or trust boundary (userspace ↔ kernel,
host ↔ guest, local ↔ remote rank).

**Run this after `/review` (correctness), not instead of it.**

---

## Checklist — run every item, report every finding

### 1. Memory safety

#### Use-after-free
- [ ] Is any pointer read or written after `free()` / `kfree()` on any path,
      including error paths and concurrent teardown?
- [ ] Is there reference counting on any object that is shared across threads
      or completion callbacks? Is `refcount_t` used (not `int` or `atomic_t`
      for security-sensitive counters)?
- [ ] RDMA-specific: is a `struct ib_device` or completion queue handle
      accessed after `ib_unregister_device()` or `ib_destroy_cq()` could
      have been called on another thread?
      *Recent example: CVE-2025-38024 — RDMA/rxe use-after-free via
      concurrent deregister and completion.*

#### Double-free
- [ ] Is any pointer freed more than once on any path?
- [ ] RDMA-specific: is `dma_buf_unpin()` called in both the success path
      and the error unwind path without a NULL guard?
      *Recent example: CVE-2026-43128 — RDMA/umem double dma_buf_unpin.*

#### Buffer overflow / out-of-bounds
- [ ] Is every array index derived from external input (message size,
      rank count, user-supplied count) bounds-checked before use?
- [ ] Is `chunk_size = count / nranks` used as an array stride? If `count`
      is not a multiple of `nranks`, does the remainder escape the bounds?
- [ ] Are `memcpy` / `memmove` lengths validated against both source and
      destination buffer sizes independently?
- [ ] Kernel-specific: is `copy_from_user()` / `copy_to_user()` used for
      all userspace memory accesses? Direct dereference of userspace pointers
      is a kernel exploit primitive.

---

### 2. Integer arithmetic

#### Overflow and underflow
- [ ] Is any value derived from user-supplied input used in arithmetic before
      being validated? Check: `count * sizeof(T)` — this overflows silently
      on 32-bit size_t if count > 2^30 for float.
- [ ] Is subtraction of unsigned values performed where the result could wrap?
      `size_t remaining = total - offset` wraps to ULONG_MAX if offset > total.
- [ ] Are rank counts, message sizes, or buffer offsets cast between signed
      and unsigned types? A negative signed value cast to size_t produces a
      huge positive number used as an allocation size — classic heap overflow.
- [ ] Kernel-specific: `tcp_add_backlog()` class bug — signed integer overflow
      in network path arithmetic. Check all `int` accumulators in hot paths.
      *Recent example: CVE-2022-50865 — signed-integer-overflow in tcp.*

#### Divide-by-zero
- [ ] Is any divisor derived from external input (rank count, buffer count,
      stride) validated as non-zero before use?
- [ ] Is `nranks == 0` or `nranks == 1` guarded before `count / nranks`?

---

### 3. Concurrency and race conditions

#### TOCTOU (Time-of-Check/Time-of-Use)
- [ ] Is any condition checked and then acted upon without holding a lock
      across both operations?
- [ ] Is a completion queue depth checked and then a slot consumed without
      atomicity? Between check and consume, another thread may consume the
      slot.
- [ ] RDMA-specific: is device state (connected/disconnected) checked and
      then a send posted without the state being stable across the two
      operations?
      *Recent example: TOCTOU in POSIX CPU timer — check+act without lock.*

#### Locking discipline
- [ ] Is `spinlock_t` acquired in interrupt context? If yes, is `spin_lock_irqsave()`
      used, not `spin_lock()`? Acquiring a non-IRQ-safe lock in interrupt
      context causes a deadlock that can be triggered remotely by flooding
      interrupts.
- [ ] Is `mutex_lock()` called from atomic context (interrupt handler,
      RCU read-side, spinlock held)? This is a kernel BUG() that can be
      triggered by a remote peer.
- [ ] Are RCU read-side critical sections kept short? Sleeping inside
      `rcu_read_lock()` is illegal and causes subtle corruption.
- [ ] MPI-specific: is `MPI_Finalize()` safe to call concurrently with
      any in-flight collective? Is there a barrier or quiesce before
      resource teardown?

---

### 4. Privilege and trust boundaries

#### Kernel ↔ userspace
- [ ] Does any kernel code trust a length, pointer, or flag value from
      userspace without validation? All userspace-supplied values are
      attacker-controlled.
- [ ] Is `capable(CAP_NET_ADMIN)` or equivalent checked before operations
      that affect the network stack or RDMA fabric?
- [ ] Are ioctl arguments fully validated for size and content before
      being passed to kernel structures?

#### Rank ↔ rank (MPI trust model)
- [ ] Does this code assume all MPI ranks are trusted? If the collective
      runs in a multi-tenant or cloud HPC environment, a malicious rank
      can send malformed messages. Check:
      - Message sizes validated before allocation
      - Rank indices validated before array indexing
      - No silent truncation of oversized messages

#### RDMA memory registration
- [ ] Are MR (memory region) permissions scoped as tightly as possible
      (`IBV_ACCESS_LOCAL_WRITE` only unless remote access is required)?
- [ ] Is MR deregistration guaranteed before the backing buffer is freed?
      Freeing the buffer while the MR is live allows remote peers to
      read/write freed memory.

---

### 5. Information disclosure

- [ ] Does any error path return internal kernel addresses, stack contents,
      or structure layout to userspace or a remote rank?
- [ ] Are kernel pointers printed with `%pK` (not `%p`) in log messages?
      `%p` leaks KASLR base addresses since kernel 4.15+.
- [ ] Are error codes returned to remote ranks minimal? Detailed error
      strings can fingerprint internal state for an attacker.
- [ ] Are MPI error strings sanitized before being propagated to
      `MPI_Error_string()` output?

---

### 6. Denial of service from remote input

- [ ] Can a remote rank send a message that causes an allocation of
      arbitrary size? (`malloc(remote_size)` without a cap.)
- [ ] Can a remote rank trigger an infinite loop? Check: retry loops
      conditioned on remote acknowledgment without a timeout or iteration
      cap.
- [ ] Can a remote rank exhaust a completion queue by never posting
      receives? Is there a high-water-mark check with backpressure?
- [ ] Kernel-specific: can a remote peer trigger `BUG_ON()` or `WARN_ON()`
      that halts the node? These must never be reachable from untrusted input.

---

## Output format

```
[CRITICAL] <finding> — exploitable, likely, direct impact
[HIGH]     <finding> — exploitable under specific conditions
[MEDIUM]   <finding> — exploitable with attacker effort or specific env
[LOW]      <finding> — hardening improvement, not directly exploitable
[PASS]     <check> — confirmed safe
```

List all CRITICAL and HIGH findings before any fixes.
For each finding include:
- File and line
- Attack scenario: how an attacker triggers this in practice
- Impact: what they achieve (crash / data corruption / privilege escalation /
  info disclosure)
- Fix: concrete code change

**Do not suggest fixes until all findings are listed.**

## What this skill does NOT cover

- Correctness bugs that aren't exploitable → use `/review`
- Architecture violations → use `/sync-arch`
- Web/API security (XSS, CSRF, SQL injection) — wrong domain for this codebase
- Cryptographic protocol design — out of scope, get a specialist

## Reference CVEs relevant to this codebase

These are recent real-world examples of the bug classes above in adjacent code:

| CVE | Subsystem | Class | Pattern |
|-----|-----------|-------|---------|
| CVE-2025-38024 | RDMA/rxe | Use-after-free | Concurrent deregister + completion |
| CVE-2026-43128 | RDMA/umem | Double-free | dma_buf_unpin in both success and error paths |
| CVE-2022-50865 | TCP | Integer overflow | Signed accumulator in network arithmetic |
| CVE-2026-43284 | ESP/XFRM | Privilege escalation | Page-cache write primitive via splice |
| CVE-2026-23231 | nf_tables | Use-after-free | Privilege escalation via chain teardown race |
