---
name: sync-arch
description: Use before writing new collective code, or when asked to check layer boundaries, architecture, or whether a change violates oneCCL's coll/atl separation. Reads docs/ARCHITECTURE.md and reports violations before any code is written.
---

# sync-arch — oneCCL architecture gatekeeper

## What this skill does

Before touching any code, read `docs/ARCHITECTURE.md` in full.
Then evaluate the current task or diff against every rule in that file.

## Checklist to run on every file in scope

1. **Transport boundary**: does any function in `coll/` call MPI, OFI,
   libfabric, or any network API directly?
   → VIOLATION. All sends/recvs must go through `comm->atl`.

2. **Memory discipline**: does any collective use `malloc` / `free` / `new`?
   → VIOLATION. Use `ccl_buffer_t` APIs.

3. **Reduction dispatch**: is any arithmetic operator (+, *, min, max)
   hardcoded instead of dispatched through `ccl_reduction_fn_t`?
   → VIOLATION.

4. **In-place safety**: if `sendbuf == recvbuf`, is there an explicit guard
   at the top of the function before any reads or writes?
   → If not, flag as potential in-place corruption.

5. **Edge cases**: are `count == 0` and `comm->size == 1` both handled
   before any arithmetic that divides by `comm->size` or indexes by `count`?
   → If not, flag divide-by-zero / empty-buffer risk.

## Output format

For each violation found:

```
[ARCH VIOLATION] <rule number> — <file>:<line>
  Found:    <what the code does>
  Required: <what it should do instead>
  Fix:      <concrete suggestion>
```

Then list all clear rules as PASS.

**Do not suggest any code changes until all violations are listed.**
