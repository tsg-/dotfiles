# GitHub Copilot instructions — oneCCL skills demo project

Note: Copilot does not support skills or slash commands. These are the
equivalent behavioral guidelines applied as persistent context.

---

## Behavioral guidelines

### Think before coding
- State assumptions explicitly before implementing.
- If multiple interpretations exist, present them — don't pick silently.
- If something is unclear, ask before writing code.

### Simplicity first
- Minimum code that solves the problem. Nothing speculative.
- No abstractions for single-use code.
- No features beyond what was asked.
- If you write 200 lines and it could be 50, rewrite it.

### Surgical changes
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- Every changed line should trace directly to the request.

### Debugging discipline
- Write a minimal reproducer that triggers the bug before editing any source.
- State the root cause explicitly before proposing a fix.
- The reproducer becomes a regression test — add it to CMakeLists.txt.

### Goal-driven execution
- Transform tasks into verifiable goals with explicit success criteria.
- For multi-step tasks, state a plan before starting.

---

## Hard rules for this codebase

1. `src/` is the `coll/` layer — no MPI/OFI/libfabric calls directly
2. All transport goes through `comm->atl` — read `docs/ARCHITECTURE.md` first
3. Every collective must handle `count==0` and `size==1`
4. `perf-thresholds.json` is a contract — relax only with explicit sign-off

---

## Commit format

```
<type>: <short headline less than 72 chars>

<description wrapped at 79 characters>

Signed-off-by: Tushar Gohad <tushar.gohad@intel.com>
```

Types: `feat`, `fix`, `refactor`, `docs`, `test`, `build`, `chore`
Never include `Co-Authored-By`.
