# CLAUDE.md — oneCCL skills demo project

> **Claude Code** loads this file plus `@AGENTS.md` (imported below).
> **Gemini CLI** loads `AGENTS.md` + `GEMINI.md` via `.gemini/settings.json`.
> **Codex CLI** reads `AGENTS.md` natively.
> **Copilot** reads `.github/copilot-instructions.md` (flat copy, no imports).

@./AGENTS.md

---

## Claude Code skills

Skills are loaded automatically from `.claude/skills/` at session startup.
Confirm with `/skills` after opening the project.

### Interactive skills (developer session)

| Command | When it fires |
|---|---|
| `/sync-arch` | Before writing or reviewing any collective code |
| `/diagnose` | When given an error log, crash, or wrong result |
| `/review` | After any implementation — before calling it done |
| `/handoff` | When session is long or branching to a prototype |
| `/perf-gate` | Before merging any change to `src/` or `atl/` |
| `/promote-repro` | After `/diagnose` writes a reproducer to `scripts/` |
| `/security-review` | Any code touching privilege boundaries, RDMA, or kernel interfaces |

### CI skills (non-interactive, GitHub Actions)

| Workflow | Trigger | Skill |
|---|---|---|
| `.github/workflows/claude-review.yml` | PR open/update | `/review` |
| `.github/workflows/arch-gate.yml` | Every PR | `/arch-gate` (JSON, exit 2) |
| `.github/workflows/perf-gate.yml` | Merge to main | `/perf-gate` |

### Skills directory layout

```
.claude/skills/
  diagnose/         reproducer-first debugging
  handoff/          session state compression
  review/           adversarial code review
  sync-arch/        interactive architecture checker
  arch-gate/        CI-mode architecture enforcer (JSON output, exit 2)
  perf-gate/        OSU benchmark regression gate
  promote-repro/    reproducer → registered CI test
  security-review/  exploitability review for kernel/RDMA/MPI code
```

Note: `.gemini/skills/` and `.agents/skills/` are symlinks to `.claude/skills/`
so all three agents share the same SKILL.md files.
