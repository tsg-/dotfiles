# GEMINI.md — oneCCL skills demo project

> Shared behavioral guidelines and project rules live in `AGENTS.md`.
> This file adds Gemini CLI–specific configuration on top.

@./AGENTS.md

---

## Gemini CLI skills

Skills are loaded from `.gemini/skills/` (symlink → `.claude/skills/`).
The same SKILL.md files work across Claude Code and Gemini CLI.

Available skills: `diagnose`, `review`, `sync-arch`, `handoff`,
`perf-gate`, `arch-gate`, `promote-repro`.

Invoke by describing the task — Gemini CLI activates the matching skill
automatically via the `activate_skill` tool. You will see a confirmation
prompt before the skill loads.
