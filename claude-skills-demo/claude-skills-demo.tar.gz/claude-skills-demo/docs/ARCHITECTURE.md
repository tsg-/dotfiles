# oneCCL architecture boundaries

## Layer map

```
 ┌─────────────────────────────────┐
 │  coll/   — collective algorithms │  ← ring_allreduce.c lives here
 │  (allreduce, allgather, etc.)   │
 ├─────────────────────────────────┤
 │  atl/    — transport abstraction │  ← ONLY layer allowed to call
 │  (atl_req_t, atl_comm_t)        │     MPI / OFI / SHM directly
 ├─────────────────────────────────┤
 │  comm/   — communicator mgmt    │
 └─────────────────────────────────┘
```

## Hard rules

1. **coll/ must never call MPI, OFI, or any network API directly.**
   All data movement goes through `comm->atl` (atl_req_t interface).

2. **Memory allocation in coll/ must use ccl_buffer_t, not malloc/free.**
   Direct malloc leaks across device/host boundaries.

3. **Reductions must dispatch through ccl_reduction_fn_t,**
   never hardcoded arithmetic. Supports user-defined ops.

4. **In-place operations (sendbuf == recvbuf) must be detected and handled**
   before the algorithm begins, not worked around mid-flight.

5. **All collectives must handle: count==0, comm->size==1, and non-float dtypes.**
