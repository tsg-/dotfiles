#pragma once
#include <stddef.h>

typedef enum { CCL_DTYPE_FLOAT = 0 } ccl_datatype_t;
typedef enum { CCL_REDUCTION_SUM = 0 } ccl_reduction_t;

typedef struct {
    int rank;
    int size;
    void *atl; /* atl transport handle — should be used for sends/recvs */
} ccl_comm_t;

int  ring_allreduce(void *sendbuf, void *recvbuf, size_t count,
                    ccl_datatype_t dtype, ccl_reduction_t op,
                    ccl_comm_t *comm);

void ring_allreduce_destroy(ccl_comm_t *comm);
