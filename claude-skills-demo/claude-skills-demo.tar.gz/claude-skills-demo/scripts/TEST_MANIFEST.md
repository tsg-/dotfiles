# Test manifest — regression tests promoted from /diagnose reproducers

Each row is a bug that was debugged with /diagnose, reproduced in isolation,
fixed, and promoted to a permanent regression test by /promote-repro.

| Test name | Bug description | Date added | PR / Issue |
|-----------|----------------|------------|------------|
| regression_single_rank | ring_allreduce SIGFPE when comm->size == 0 (divide-by-zero in chunk_size calculation) | 2026-05-22 | demo |

## How to add a row

Run `/promote-repro scripts/repro_<name>.c` — the skill writes the CMake
target and appends the row automatically.

## Running regression suite

```bash
cmake -B build && cmake --build build
ctest --build-dir build -L regression -V
```

All tests in this manifest must pass on every commit to main.
