# Agent orchestration loop — demo setup

## The concept

> "I don't prompt Claude anymore. I write loops and the loops do the work.
> My job is to write loops."
> — Boris Cherny, creator of Claude Code (Acquired Unplugged, June 2026)

This loop demonstrates **level 3 agentic engineering**:

| Level | What the human does |
|---|---|
| 1 | Writes code |
| 2 | Prompts Claude to write code |
| **3** | **Writes loops that orchestrate Claude agents** |

The loop watches `scripts/repro_*.c` for new reproducers dropped by
`/diagnose`. For each new file it automatically runs `/arch-gate`,
`/promote-repro`, and `/review` — no human prompts any step.

---

## Demo setup — three terminals

```
┌─────────────────────────┐  ┌─────────────────────────┐
│  Terminal 1 (projected) │  │  Terminal 2 (side pane)  │
│                         │  │                          │
│  claude                 │  │  python3 scripts/loop/   │
│  (interactive session   │  │    demo_loop.py          │
│   with /diagnose,       │  │                          │
│   /review, /handoff)    │  │  [loop watching...]      │
└─────────────────────────┘  └─────────────────────────┘
                              ┌─────────────────────────┐
                              │  Terminal 3 (trigger)   │
                              │                         │
                              │  python3 scripts/loop/  │
                              │    trigger_loop.py      │
                              │                         │
                              │  (run at 12:30 mark)    │
                              └─────────────────────────┘
```

On a single server, use `tmux` to split the screen:

```bash
# Start a tmux session
tmux new-session -s demo

# Split into three panes
Ctrl-b %      # vertical split
Ctrl-b "      # horizontal split of right pane

# Pane 1 (left, large): interactive Claude Code session
cd oneccl-skills-demo && claude

# Pane 2 (top right): the loop
python3 scripts/loop/demo_loop.py

# Pane 3 (bottom right): trigger — run at the 12:30 mark
python3 scripts/loop/trigger_loop.py
```

---

## Timing in the demo

The loop section replaces the last 2 minutes of `/handoff` and adds
5 minutes. Revised timing:

| Time | What happens |
|---|---|
| 0:00–1:00 | Framing (unchanged) |
| 1:00–4:00 | /sync-arch (unchanged) |
| 4:00–8:00 | /diagnose (unchanged) |
| 8:00–12:00 | /review (unchanged) |
| 12:00–13:30 | /handoff — show the concept, start the file |
| **13:30** | **Run trigger_loop.py in pane 3** |
| 13:30–18:00 | Loop fires: arch-gate → promote-repro → review |
| 18:00–20:00 | Wrap-up — "this is what Boris means by writing loops" |

---

## What the audience sees in the loop pane

```
────────────────────────────────────────────────────
  New reproducer detected: repro_inplace.c
────────────────────────────────────────────────────

[13:31:02] Triggering agent pipeline for: repro_inplace
[13:31:02] (No human prompting from this point — the loop drives everything)

────────────────────────────────────────────────────
  Step 1 / 3  —  arch-gate
────────────────────────────────────────────────────

[13:31:02] → invoking claude: arch-gate
[13:31:04]   arch-gate: PASS — 5 rules checked, 0 violations

────────────────────────────────────────────────────
  Step 2 / 3  —  promote-repro
────────────────────────────────────────────────────

[13:31:04] → invoking claude: promote-repro
[13:31:06]   promote-repro: registered → ctest target: regression_inplace
[13:31:06]   PR comment draft: /tmp/promote_repro_comment.md

────────────────────────────────────────────────────
  Step 3 / 3  —  review
────────────────────────────────────────────────────

[13:31:06] → invoking claude: review
[13:31:08]   review: PASS — no critical or major findings
[13:31:08]     [PASS] In-place aliasing guard — sendbuf==recvbuf detected at entry
[13:31:08]     [PASS] Edge case count==0 returns cleanly
[13:31:08]     [MINOR] ring_allreduce_destroy: no reference counting

────────────────────────────────────────────────────
  Pipeline complete
────────────────────────────────────────────────────

[13:31:08] Reproducer:  scripts/repro_inplace.c
[13:31:08] arch-gate:   PASS
[13:31:08] promote:     registered as ctest regression
[13:31:08] review:      adversarial pass complete
[13:31:08] The loop continues watching for new reproducers...
```

---

## Talking points during the loop section

**Before triggering (13:00 mark):**
> "Notice the second terminal. That loop has been running the whole time
> we've been talking. It's not waiting for me. It's watching the filesystem."

**After triggering (13:30 mark):**
> "I just dropped a new reproducer. I didn't type a single prompt.
> Watch the loop."

**While the pipeline runs:**
> "arch-gate first — checks architecture compliance before anything else.
> Then promote-repro — it just registered this as a ctest regression test.
> Then an adversarial review. Three skill invocations. Zero prompts from me."

**Wrap-up:**
> "Boris Cherny said his job is to write loops. This is what he means.
> The skills we spent 12 minutes building — they're not slash commands
> you type. They're the vocabulary the loop speaks.
> My job was to write this loop. Claude's job is to run it."
