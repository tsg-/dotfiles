#!/usr/bin/env python3
"""
demo_loop.py — oneCCL agent orchestration loop

Watches scripts/repro_*.c for new files dropped by /diagnose.
For each new reproducer, automatically:
  1. Runs /arch-gate  (CI architecture check — JSON, no human needed)
  2. Runs /promote-repro (registers it as a ctest regression test)
  3. Runs /review  (adversarial review of the fix patch, if present)
  4. Prints a structured summary

This is the "write loops, not prompts" pattern from Boris Cherny's talk.
No human types anything after the loop starts.

Usage:
    python3 scripts/loop/demo_loop.py

    In a second terminal during the demo, while /handoff is being shown
    in the first terminal. The loop is already running and watching.
"""

import os
import sys
import time
import json
import subprocess
import datetime
from pathlib import Path

# ── Config ────────────────────────────────────────────────────────────────────
PROJECT_ROOT  = Path(__file__).parent.parent.parent  # oneccl-skills-demo/
SCRIPTS_DIR   = PROJECT_ROOT / "scripts"
WATCH_GLOB    = "repro_*.c"
POLL_INTERVAL = 2   # seconds between filesystem checks
LOG_FILE      = PROJECT_ROOT / "scripts" / "loop" / "loop.log"

# ANSI colours for terminal output
class C:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    CYAN   = "\033[96m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    DIM    = "\033[2m"
    PURPLE = "\033[95m"

def ts():
    return datetime.datetime.now().strftime("%H:%M:%S")

def log(msg, color=C.DIM):
    line = f"{C.DIM}[{ts()}]{C.RESET} {color}{msg}{C.RESET}"
    print(line, flush=True)
    with open(LOG_FILE, "a") as f:
        f.write(f"[{ts()}] {msg}\n")

def section(title, color=C.CYAN):
    bar = "─" * 60
    print(f"\n{color}{C.BOLD}{bar}", flush=True)
    print(f"  {title}", flush=True)
    print(f"{bar}{C.RESET}\n", flush=True)

def run_claude(prompt, label):
    """
    Run claude --print with a skill-prefixed prompt.
    Returns (stdout, returncode).
    In demo mode without real claude binary, returns simulated output.
    """
    log(f"→ invoking claude: {label}", C.PURPLE)

    # Check if claude binary exists
    claude_bin = subprocess.run(["which", "claude"], capture_output=True).returncode == 0

    if not claude_bin:
        # Demo simulation mode — produce realistic-looking output
        return _simulate_claude(prompt, label), 0

    result = subprocess.run(
        ["claude", "--print", "--output-format", "json"],
        input=prompt,
        capture_output=True,
        text=True,
        cwd=str(PROJECT_ROOT),
        timeout=120,
    )
    return result.stdout, result.returncode

def _simulate_claude(prompt, label):
    """Produce realistic simulated output for demo environments without Claude CLI."""
    time.sleep(1.5)  # simulate thinking time

    if "arch-gate" in label:
        return json.dumps({
            "schema": "arch-gate/v1",
            "checked_files": ["src/ring_allreduce.c"],
            "violations": [],
            "passes": [
                {"rule": 1, "description": "No direct MPI/OFI calls in coll/ layer"},
                {"rule": 2, "description": "No direct malloc/free found in coll/ files"},
                {"rule": 3, "description": "Reduction dispatched through ccl_reduction_fn_t"},
                {"rule": 4, "description": "In-place guard present at top of function"},
                {"rule": 5, "description": "count==0 and size==1 guards in place"},
            ],
            "summary": {"violation_count": 0, "pass_count": 5, "exit_code": 0}
        })

    if "promote-repro" in label:
        return json.dumps({
            "status": "promoted",
            "test_name": "regression_single_rank",
            "cmake_target": "repro_single_rank",
            "manifest_updated": True,
            "pr_comment_written": "/tmp/promote_repro_comment.md",
            "summary": "Reproducer promoted to ctest regression suite. Will fail if SIGFPE bug reappears."
        })

    if "review" in label:
        return json.dumps({
            "findings": [
                {"level": "PASS", "check": "In-place aliasing guard — sendbuf==recvbuf detected at entry"},
                {"level": "PASS", "check": "Edge case count==0 returns cleanly"},
                {"level": "PASS", "check": "Edge case nranks==0 returns -1 before division"},
                {"level": "MINOR", "check": "ring_allreduce_destroy: no reference counting — callers may hold stale pointer"},
            ],
            "summary": {"critical": 0, "major": 0, "minor": 1, "pass": 3}
        })

    return json.dumps({"status": "ok", "summary": "Completed"})

def format_arch_result(output, rc):
    try:
        data = json.loads(output)
        v = data.get("summary", {}).get("violation_count", 0)
        p = data.get("summary", {}).get("pass_count", 0)
        if v == 0:
            log(f"  arch-gate: {C.GREEN}PASS{C.RESET} — {p} rules checked, 0 violations", C.GREEN)
        else:
            log(f"  arch-gate: {C.RED}FAIL{C.RESET} — {v} violation(s) found", C.RED)
            for viol in data.get("violations", []):
                log(f"    [VIOLATION] Rule {viol['rule']}: {viol['found']}", C.RED)
        return v == 0
    except Exception:
        log(f"  arch-gate: exit {rc}", C.YELLOW if rc == 0 else C.RED)
        return rc == 0

def format_promote_result(output):
    try:
        data = json.loads(output)
        name = data.get("test_name", "unknown")
        log(f"  promote-repro: {C.GREEN}registered{C.RESET} → ctest target: {name}", C.GREEN)
        log(f"  PR comment draft: {data.get('pr_comment_written', 'see /tmp/')}", C.DIM)
    except Exception:
        log(f"  promote-repro: done", C.GREEN)

def format_review_result(output):
    try:
        data = json.loads(output)
        s = data.get("summary", {})
        crit = s.get("critical", 0)
        maj  = s.get("major", 0)
        if crit > 0:
            log(f"  review: {C.RED}{crit} CRITICAL finding(s) — do not merge{C.RESET}", C.RED)
        elif maj > 0:
            log(f"  review: {C.YELLOW}{maj} MAJOR finding(s) — review before merge{C.RESET}", C.YELLOW)
        else:
            log(f"  review: {C.GREEN}PASS{C.RESET} — no critical or major findings", C.GREEN)
        for f in data.get("findings", []):
            lvl = f["level"]
            color = C.RED if lvl=="CRITICAL" else C.YELLOW if lvl in ("MAJOR","MINOR") else C.GREEN
            log(f"    [{lvl}] {f['check']}", color)
    except Exception:
        log(f"  review: done", C.GREEN)

def process_reproducer(repro_file: Path):
    """Run the full agent pipeline for a new reproducer — no human prompting."""
    name = repro_file.stem  # e.g. repro_single_rank

    section(f"New reproducer detected: {repro_file.name}", C.CYAN)
    log(f"Triggering agent pipeline for: {name}", C.BOLD)
    log("(No human prompting from this point — the loop drives everything)", C.DIM)

    # ── Step 1: arch-gate ────────────────────────────────────────────────────
    section("Step 1 / 3  —  arch-gate", C.YELLOW)
    log("Running architecture compliance check...", C.DIM)

    arch_prompt = f"""/arch-gate

Check src/ring_allreduce.c for layer violations after the fix
associated with {repro_file.name}.
Output JSON only."""

    arch_out, arch_rc = run_claude(arch_prompt, "arch-gate")
    arch_ok = format_arch_result(arch_out, arch_rc)

    if not arch_ok:
        log("arch-gate failed — skipping promotion. Fix violations first.", C.RED)
        return

    # ── Step 2: promote-repro ────────────────────────────────────────────────
    section("Step 2 / 3  —  promote-repro", C.YELLOW)
    log("Promoting reproducer to registered ctest regression test...", C.DIM)

    promote_prompt = f"""/promote-repro scripts/{repro_file.name}

Validate, add to CMakeLists.txt, update TEST_MANIFEST.md,
and draft a PR comment. Output JSON summary."""

    promote_out, _ = run_claude(promote_prompt, "promote-repro")
    format_promote_result(promote_out)

    # ── Step 3: review ───────────────────────────────────────────────────────
    section("Step 3 / 3  —  review", C.YELLOW)
    log("Running adversarial review on src/ring_allreduce.c...", C.DIM)

    review_prompt = f"""/review

Review src/ring_allreduce.c focusing on the fix related to
{repro_file.name}. Output JSON with findings array and summary."""

    review_out, _ = run_claude(review_prompt, "review")
    format_review_result(review_out)

    # ── Summary ──────────────────────────────────────────────────────────────
    section("Pipeline complete", C.GREEN)
    log(f"Reproducer:  scripts/{repro_file.name}", C.BOLD)
    log(f"arch-gate:   {'PASS' if arch_ok else 'FAIL'}", C.GREEN if arch_ok else C.RED)
    log(f"promote:     registered as ctest regression", C.GREEN)
    log(f"review:      adversarial pass complete", C.GREEN)
    log("", C.RESET)
    log("The loop continues watching for new reproducers...", C.DIM)


def main():
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

    section("oneCCL agent orchestration loop", C.PURPLE)
    print(f"""  {C.BOLD}\"My job is to write loops.\"
  — Boris Cherny, creator of Claude Code{C.RESET}

  This loop watches {C.CYAN}scripts/repro_*.c{C.RESET} for files dropped by /diagnose.
  For each new reproducer it automatically runs:

    {C.YELLOW}1. /arch-gate{C.RESET}      — layer compliance check (JSON, exit 2 on violation)
    {C.YELLOW}2. /promote-repro{C.RESET}  — register as ctest regression test
    {C.YELLOW}3. /review{C.RESET}         — adversarial correctness pass

  No human prompts any of these steps.
  {C.DIM}Press Ctrl-C to stop.{C.RESET}
""", flush=True)

    known = set(SCRIPTS_DIR.glob(WATCH_GLOB))
    log(f"Watching {SCRIPTS_DIR}/{WATCH_GLOB}", C.DIM)
    log(f"Already present (will not reprocess): {[f.name for f in known]}", C.DIM)
    log("Waiting for /diagnose to drop a new reproducer...\n", C.DIM)

    try:
        while True:
            current = set(SCRIPTS_DIR.glob(WATCH_GLOB))
            new_files = current - known

            for f in sorted(new_files):
                process_reproducer(f)
                known.add(f)

            time.sleep(POLL_INTERVAL)

    except KeyboardInterrupt:
        print(f"\n{C.DIM}Loop stopped.{C.RESET}", flush=True)
        sys.exit(0)

if __name__ == "__main__":
    main()
