#!/bin/bash
# scripts/run_osu.sh
#
# Runs the OSU micro-benchmark suite and outputs JSON results.
# Called by .github/workflows/perf-gate.yml and /perf-gate skill.
#
# Environment variables:
#   OSU_DIR   — path to OSU benchmark binaries (default below)
#   MPIRUN    — MPI launcher (default: mpirun)
#   HOSTFILE  — MPI hostfile for multi-node runs (default: scripts/hostfile)
#   RANKS_BIG — rank count for "large" allreduce test (default: 64)

set -euo pipefail

OSU_DIR="${OSU_DIR:-/usr/local/libexec/osu-micro-benchmarks/mpi}"
MPIRUN="${MPIRUN:-mpirun}"
HOSTFILE="${HOSTFILE:-scripts/hostfile}"
RANKS_BIG="${RANKS_BIG:-64}"
MSG_SIZE=4096   # bytes — 1024 floats, representative of allreduce workloads

# ── Validate environment ──────────────────────────────────────────────────────
for bin in \
  "$OSU_DIR/pt2pt/osu_latency" \
  "$OSU_DIR/pt2pt/osu_bw" \
  "$OSU_DIR/collective/osu_allreduce"; do
  if [ ! -f "$bin" ]; then
    echo "ERROR: $bin not found. Set OSU_DIR or install OSU MPI Benchmarks." >&2
    exit 1
  fi
done

if [ ! -f "$HOSTFILE" ] && [ "$RANKS_BIG" -gt 1 ]; then
  echo "ERROR: hostfile not found at $HOSTFILE. Multi-rank tests require a hostfile." >&2
  exit 1
fi

# ── Helper: extract median latency from OSU output for a given message size ──
extract_latency() {
  local output="$1"
  local size="$2"
  echo "$output" | awk -v s="$size" '$1 == s {print $2}' | head -1
}

extract_bw() {
  local output="$1"
  local size="$2"
  echo "$output" | awk -v s="$size" '$1 == s {print $2}' | head -1
}

# ── Run benchmarks ────────────────────────────────────────────────────────────

echo "Running OSU latency (2 ranks, 4-byte message)..." >&2
LAT_OUT=$($MPIRUN -n 2 -hostfile "$HOSTFILE" \
  "$OSU_DIR/pt2pt/osu_latency" -m 4:4 -i 1000 2>/dev/null)
LAT_P50=$(extract_latency "$LAT_OUT" 4)

# p99 requires OSU >= 5.9; fall back gracefully
echo "Running OSU latency p99 (2 ranks)..." >&2
LAT_P99_OUT=$($MPIRUN -n 2 -hostfile "$HOSTFILE" \
  "$OSU_DIR/pt2pt/osu_latency" -m 4:4 -i 1000 --percentile 99 2>/dev/null || echo "")
LAT_P99=$(extract_latency "$LAT_P99_OUT" 4)
LAT_P99="${LAT_P99:-null}"   # null if OSU too old

echo "Running OSU bandwidth (2 ranks, 1MB message)..." >&2
BW_OUT=$($MPIRUN -n 2 -hostfile "$HOSTFILE" \
  "$OSU_DIR/pt2pt/osu_bw" -m 1048576:1048576 -i 100 2>/dev/null)
BW=$(extract_bw "$BW_OUT" 1048576)

echo "Running OSU allreduce (8 ranks, ${MSG_SIZE}-byte message)..." >&2
AR8_OUT=$($MPIRUN -n 8 -hostfile "$HOSTFILE" \
  "$OSU_DIR/collective/osu_allreduce" -m ${MSG_SIZE}:${MSG_SIZE} -i 200 2>/dev/null)
AR8_US=$(extract_latency "$AR8_OUT" "$MSG_SIZE")
AR8_MS=$(echo "scale=4; $AR8_US / 1000" | bc)

echo "Running OSU allreduce ($RANKS_BIG ranks, ${MSG_SIZE}-byte message)..." >&2
AR_BIG_OUT=$($MPIRUN -n "$RANKS_BIG" -hostfile "$HOSTFILE" \
  "$OSU_DIR/collective/osu_allreduce" -m ${MSG_SIZE}:${MSG_SIZE} -i 200 2>/dev/null)
AR_BIG_US=$(extract_latency "$AR_BIG_OUT" "$MSG_SIZE")
AR_BIG_MS=$(echo "scale=4; $AR_BIG_US / 1000" | bc)

# ── Output JSON ───────────────────────────────────────────────────────────────
cat <<JSON
{
  "_timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "_commit": "$(git rev-parse HEAD 2>/dev/null || echo unknown)",
  "_mpirun": "$MPIRUN",
  "_osu_dir": "$OSU_DIR",
  "osu_latency_p50_us":  $LAT_P50,
  "osu_latency_p99_us":  $LAT_P99,
  "osu_bw_gbs":          $BW,
  "osu_allreduce_8_ms":  $AR8_MS,
  "osu_allreduce_${RANKS_BIG}_ms": $AR_BIG_MS
}
JSON
