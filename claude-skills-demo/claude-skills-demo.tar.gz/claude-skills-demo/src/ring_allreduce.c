/*
 * ring_allreduce.c
 *
 * Demonstration oneCCL collective extension: ring-based allreduce.
 * Intended for tutorial use — contains deliberate architectural and
 * correctness issues for skill demonstrations.
 */

#include "ring_allreduce.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* ------------------------------------------------------------------ */
/* BUG #1 (sync-arch): Transport logic lives directly in the           */
/* collective layer. In oneCCL, transport is owned by atl/ not coll/. */
/* ------------------------------------------------------------------ */
static int send_chunk(int dest_rank, void *buf, size_t count) {
    /* Direct MPI call from inside collective — violates oneCCL layering.
     * Should go through atl_req_t / comm->atl interface instead. */
    // MPI_Send(buf, count, MPI_FLOAT, dest_rank, 0, MPI_COMM_WORLD);
    (void)dest_rank; (void)buf; (void)count;
    return 0;
}

static int recv_chunk(int src_rank, void *buf, size_t count) {
    // MPI_Recv(buf, count, MPI_FLOAT, src_rank, 0, MPI_COMM_WORLD,
    //          MPI_STATUS_IGNORE);
    (void)src_rank; (void)buf; (void)count;
    return 0;
}

/* ------------------------------------------------------------------ */
/* BUG #2 (diagnose): No validation of count==0 or comm_size==1.      */
/* Divide-by-zero on chunk_size when count < comm_size.               */
/* ------------------------------------------------------------------ */
int ring_allreduce(void *sendbuf, void *recvbuf, size_t count,
                   ccl_datatype_t dtype, ccl_reduction_t op,
                   ccl_comm_t *comm) {

    int rank     = comm->rank;
    int nranks   = comm->size;

    /* BUG: no guard for nranks==1 or count==0 */
    size_t chunk_size = count / nranks;   /* divide-by-zero if nranks=0 */

    float *sbuf = (float *)sendbuf;
    float *rbuf = (float *)recvbuf;

    /* ---------------------------------------------------------------- */
    /* BUG #3 (review): Buffer aliasing — recvbuf is used as accumulator */
    /* before the scatter-reduce phase is complete. If sendbuf==recvbuf  */
    /* (in-place), this corrupts data on ranks > 0.                      */
    /* ---------------------------------------------------------------- */
    memcpy(recvbuf, sendbuf, count * sizeof(float));

    /* Scatter-reduce phase */
    for (int step = 0; step < nranks - 1; step++) {
        int send_to  = (rank + 1)          % nranks;
        int recv_from = (rank - 1 + nranks) % nranks;

        int send_chunk_idx = (rank - step + nranks) % nranks;
        int recv_chunk_idx = (rank - step - 1 + nranks) % nranks;

        float *send_ptr = rbuf + send_chunk_idx * chunk_size;
        float *recv_ptr = rbuf + recv_chunk_idx * chunk_size;

        /* BUG #4 (review): recv_ptr is read (accumulation below) before  */
        /* recv_chunk() completes — no synchronization between send/recv.  */
        send_chunk(send_to,   send_ptr, chunk_size);
        recv_chunk(recv_from, recv_ptr, chunk_size);

        /* Accumulate — op hardcoded to sum; ignores ccl_reduction_t op */
        for (size_t i = 0; i < chunk_size; i++) {
            recv_ptr[i] += send_ptr[i];
        }
    }

    /* Allgather phase — omitted for brevity */

    return 0;
}

/* ------------------------------------------------------------------ */
/* BUG #5 (handoff): This file is 200+ lines into a 2000-line session. */
/* Context is getting stale. /handoff would compress state here.       */
/* ------------------------------------------------------------------ */
void ring_allreduce_destroy(ccl_comm_t *comm) {
    /* BUG: comm is freed but callers may still hold a reference.
     * No reference counting. */
    free(comm);
}
